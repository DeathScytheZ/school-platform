import{l as o,d as r}from"../chunks/B0e3DZEQ.js";export{o as load_css,r as start};
